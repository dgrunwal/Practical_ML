"""
02 - Clustering with k-means
============================
UNSUPERVISED learning: no labels given. The algorithm finds groups
on its own by pulling points toward k moving centers (centroids).

Run:  python 02_clustering_kmeans.py
Needs: scikit-learn, numpy
"""

from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# Make 3 natural blobs of points (we hide the true labels from k-means)
X, _true = make_blobs(n_samples=300, centers=3, cluster_std=1.0, random_state=0)

km = KMeans(n_clusters=3, n_init=10, random_state=0)
labels = km.fit_predict(X)          # k-means invents its own group numbers

print("k-means found 3 clusters with no labels to learn from.")
print("Cluster centers (centroids):")
for i, c in enumerate(km.cluster_centers_):
    print(f"  cluster {i}: ({c[0]:.2f}, {c[1]:.2f})")

# Silhouette score: how tight/separated the clusters are (-1..1, higher is better)
print(f"\nsilhouette score = {silhouette_score(X, labels):.3f}  (closer to 1 is better)")
print("\nTip: a k-MEANS TREE just applies this recursively inside each cluster.")
