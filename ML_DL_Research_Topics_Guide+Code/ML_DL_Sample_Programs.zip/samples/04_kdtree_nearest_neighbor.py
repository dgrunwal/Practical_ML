"""
04 - k-d Tree Nearest-Neighbour Search
======================================
A k-d tree organizes points so you can find the closest ones WITHOUT
comparing against every point. This is the idea behind FLANN's speed.

Run:  python 04_kdtree_nearest_neighbor.py
Needs: scikit-learn, numpy
"""

import numpy as np
from sklearn.neighbors import KDTree

rng = np.random.default_rng(0)
points = rng.random((1000, 3))     # 1000 points in 3-D space

tree = KDTree(points)              # build the tree once

query = np.array([[0.5, 0.5, 0.5]])
dist, idx = tree.query(query, k=5)  # 5 nearest neighbours to the query

print("Query point:", query[0])
print("\n5 nearest neighbours (index : distance):")
for i, d in zip(idx[0], dist[0]):
    print(f"  point {i:4d} : {d:.4f}")

print("\nThe tree pruned away most of the 1000 points instead of checking all.")
print("Note: in VERY high dimensions this pruning stops helping")
print("(the 'curse of dimensionality') - that's when FLANN/HNSW step in.")
