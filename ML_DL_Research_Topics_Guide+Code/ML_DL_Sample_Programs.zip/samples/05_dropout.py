"""
05 - Dropout, from scratch (no deep-learning framework needed)
==============================================================
Dropout randomly switches off a fraction of neurons during TRAINING.
This stops the network over-relying on any single neuron and reduces
overfitting. At TEST time all neurons are on (outputs are scaled).

This tiny NumPy demo shows the masking mechanic itself.

Run:  python 05_dropout.py
Needs: numpy
"""

import numpy as np

rng = np.random.default_rng(0)


def dropout_forward(activations, p_keep, training):
    """Apply dropout to a layer's activations.
    p_keep = probability a neuron is KEPT (e.g. 0.8 keeps 80%)."""
    if not training:
        return activations                      # test time: use everything
    mask = rng.random(activations.shape) < p_keep
    # "inverted dropout": scale so the average signal size stays the same
    return activations * mask / p_keep


layer = np.ones(10)     # pretend a layer output 1.0 on every neuron

print("Original activations :", layer)
print("\nThree TRAINING passes (different neurons drop each time):")
for t in range(3):
    print(f"  pass {t+1}:", np.round(dropout_forward(layer, p_keep=0.6, training=True), 2))

print("\nTEST pass (nothing dropped):")
print("        ", np.round(dropout_forward(layer, p_keep=0.6, training=False), 2))

print("\nEach pass trains a slightly different 'sub-network' - like a")
print("built-in ensemble that generalizes better.")
