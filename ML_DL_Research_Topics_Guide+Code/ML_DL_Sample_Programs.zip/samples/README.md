# Sample Programs — Research Topics in ML & DL

Beginner-friendly Python examples that accompany the training guide.
Each file is short, commented, and runnable on its own.

## Setup

    pip install scikit-learn numpy

(That's all you need — every example uses only these two libraries.)

## The programs

| File | Concept it illustrates |
|------|------------------------|
| `01_classification_vs_regression.py` | Supervised learning: predict a category vs. a number |
| `02_clustering_kmeans.py`            | Unsupervised learning: k-means finds groups with no labels |
| `03_multilabel.py`                   | The two multi-label approaches: problem transformation & algorithm adaptation |
| `04_kdtree_nearest_neighbor.py`      | k-d tree fast nearest-neighbour search (the idea behind FLANN) |
| `05_dropout.py`                      | Dropout regularization mechanic, from scratch |
| `06_residual_block.py`               | Residual / skip connection: output = F(x) + x |
| `07_extreme_learning_machine.py`     | ELM: random frozen first layer + one-shot least-squares solve |

## How to run

    python 01_classification_vs_regression.py

Each script prints its results to the screen and explains what just happened.

## Notes for learners

- These are teaching examples chosen for clarity, not speed records.
- The GAN, scene-recognition (Places), and full FLANN examples are left out
  of the runnable set because they need large datasets or GPUs; the guide
  explains them conceptually and links to good tutorials instead.

© 2025 David Grunwald. All rights reserved.
