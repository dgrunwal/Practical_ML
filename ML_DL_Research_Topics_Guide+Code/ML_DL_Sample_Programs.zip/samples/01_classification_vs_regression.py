"""
01 - Classification vs Regression
=================================
The two halves of SUPERVISED learning, side by side.

  * Classification -> predict a CATEGORY  (which class?)
  * Regression     -> predict a NUMBER    (how much?)

Run:  python 01_classification_vs_regression.py
Needs: scikit-learn, numpy   ->  pip install scikit-learn numpy
"""

from sklearn.datasets import load_iris, load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import accuracy_score, mean_squared_error


def classification_demo():
    # Iris: predict which of 3 flower species (a category)
    X, y = load_iris(return_X_y=True)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=0)

    clf = RandomForestClassifier(random_state=0)
    clf.fit(Xtr, ytr)
    preds = clf.predict(Xte)

    print("CLASSIFICATION (predict a category)")
    print(f"  accuracy = {accuracy_score(yte, preds):.3f}")
    print(f"  example prediction: class {preds[0]} (0, 1, or 2)\n")


def regression_demo():
    # Diabetes: predict a continuous disease-progression score (a number)
    X, y = load_diabetes(return_X_y=True)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=0)

    reg = RandomForestRegressor(random_state=0)
    reg.fit(Xtr, ytr)
    preds = reg.predict(Xte)

    rmse = mean_squared_error(yte, preds) ** 0.5
    print("REGRESSION (predict a number)")
    print(f"  RMSE = {rmse:.1f}")
    print(f"  example prediction: {preds[0]:.1f} (a real value)\n")


if __name__ == "__main__":
    classification_demo()
    regression_demo()
    print("Same setup, same forest - only the TARGET differs: label vs. number.")
