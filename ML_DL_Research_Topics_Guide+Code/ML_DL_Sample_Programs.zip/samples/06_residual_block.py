"""
06 - A Residual (Skip) Connection, in plain NumPy
=================================================
ResNets add the block's INPUT back to its OUTPUT:  output = F(x) + x
The shortcut lets the signal (and the learning gradient) skip past
layers, so very deep networks still train well.

This demo shows the "+ x" that defines a residual block.

Run:  python 06_residual_block.py
Needs: numpy
"""

import numpy as np

rng = np.random.default_rng(0)


def relu(z):
    return np.maximum(0, z)


def plain_block(x, W1, W2):
    """Ordinary block: must relearn the whole mapping."""
    h = relu(x @ W1)
    return relu(h @ W2)


def residual_block(x, W1, W2):
    """Residual block: only learns a small adjustment F(x), then adds x."""
    h = relu(x @ W1)
    f_x = h @ W2          # the learned "adjustment"
    return relu(f_x + x)  # <-- the skip connection


x = rng.normal(size=(1, 8))
W1 = rng.normal(size=(8, 8)) * 0.1
W2 = rng.normal(size=(8, 8)) * 0.1

print("input x        :", np.round(x, 2))
print("plain block    :", np.round(plain_block(x, W1, W2), 2))
print("residual block :", np.round(residual_block(x, W1, W2), 2))
print("\nThe residual output stays close to x plus a small change -")
print("that shortcut is what makes 100+ layer networks trainable.")
