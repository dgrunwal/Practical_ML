"""
03 - Multi-Label Learning (the two typical approaches)
======================================================
An item can carry SEVERAL labels at once (e.g. a photo tagged both
"beach" AND "sunset"). The research names two approaches:

  1. PROBLEM TRANSFORMATION - turn the multi-label task into many
     single-label problems, then use ordinary classifiers.
  2. ALGORITHM ADAPTATION - modify one algorithm to output many
     labels directly (e.g. multi-label k-NN).

Run:  python 03_multilabel.py
Needs: scikit-learn, numpy
"""

from sklearn.datasets import make_multilabel_classification
from sklearn.model_selection import train_test_split
from sklearn.multiclass import OneVsRestClassifier      # problem transformation
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier      # algorithm adaptation
from sklearn.metrics import f1_score

X, Y = make_multilabel_classification(
    n_samples=400, n_features=20, n_classes=5, n_labels=2, random_state=0
)
Xtr, Xte, Ytr, Yte = train_test_split(X, Y, test_size=0.3, random_state=0)

# --- Approach 1: Problem transformation (Binary Relevance) ---
# One yes/no classifier per label, bundled by OneVsRestClassifier.
br = OneVsRestClassifier(LogisticRegression(max_iter=1000))
br.fit(Xtr, Ytr)
f1_br = f1_score(Yte, br.predict(Xte), average="micro")

# --- Approach 2: Algorithm adaptation (multi-label k-NN) ---
# k-NN natively handles a label matrix, predicting several labels at once.
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(Xtr, Ytr)
f1_knn = f1_score(Yte, knn.predict(Xte), average="micro")

print("PROBLEM TRANSFORMATION (Binary Relevance)")
print(f"  micro-F1 = {f1_br:.3f}")
print("ALGORITHM ADAPTATION (multi-label k-NN)")
print(f"  micro-F1 = {f1_knn:.3f}")
print("\nBoth predict a SET of labels per item, not just one.")
