"""
07 - Extreme Learning Machine (ELM) from scratch
================================================
The whole ELM trick in ~15 lines:

  1. First layer weights are RANDOM and FROZEN (never trained).
  2. Output weights are SOLVED in one step with least squares.

No backpropagation, no iterating - so it trains extremely fast.

Run:  python 07_extreme_learning_machine.py
Needs: scikit-learn, numpy
"""

import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

rng = np.random.default_rng(0)

X, y = load_iris(return_X_y=True)
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=0)

# one-hot encode the 3 classes for the least-squares solve
Ytr = np.eye(3)[ytr]

n_hidden = 50
W = rng.normal(size=(X.shape[1], n_hidden))   # 1. random input->hidden weights
b = rng.normal(size=n_hidden)                 #    random biases (both FROZEN)


def hidden(A):
    return np.tanh(A @ W + b)                  # random nonlinear feature map


H = hidden(Xtr)
# 2. solve hidden->output weights directly (pseudo-inverse = one-shot least squares)
beta = np.linalg.pinv(H) @ Ytr

# predict
pred = hidden(Xte) @ beta
pred_labels = pred.argmax(axis=1)

print("Extreme Learning Machine (single-hidden-layer, no backprop)")
print(f"  hidden neurons : {n_hidden}")
print(f"  test accuracy  : {accuracy_score(yte, pred_labels):.3f}")
print("\nTrained in ONE matrix solve - no gradient descent loop at all.")
