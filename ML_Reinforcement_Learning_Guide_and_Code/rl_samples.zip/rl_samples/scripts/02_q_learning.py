"""
02_q_learning.py
================
GOAL: Build a real learning agent using **Q-learning**.

This demonstrates several concepts from the guide at once:
  * VALUE LEARNING  - we learn a value for every (state, action) pair.
  * VALUE-BASED AGENT - behaviour comes from those values, not a stored policy.
  * MODEL-FREE AGENT  - we never model how the world works; we learn from
                        experience (trial and error) only.
  * DISCOUNT FACTOR (gamma) - future rewards count a little less than now.
  * TD (TEMPORAL-DIFFERENCE) ERROR - the (target - current estimate) term.
  * EXPLORATION vs EXPLOITATION - epsilon-greedy: mostly use the best known
                                  move, but now and then try a random one.

The "Q-table" is a grid of numbers, Q[state][action], estimating how good it is
to take `action` in `state`. We nudge those numbers toward reality each step.

Run:
    python 02_q_learning.py
"""

import numpy as np
from shared_env import make_env, ACTIONS


def train(episodes=5000, alpha=0.8, gamma=0.95,
          epsilon=1.0, min_epsilon=0.01, decay=0.001, seed=0):
    """Train a Q-learning agent and return the learned Q-table."""
    env = make_env()
    n_states = env.observation_space.n
    n_actions = env.action_space.n

    # Q-table starts at all zeros: we know nothing yet.
    Q = np.zeros((n_states, n_actions))
    rng = np.random.default_rng(seed)
    rewards_per_episode = []

    for ep in range(episodes):
        state, _ = env.reset(seed=seed + ep)
        done = False
        total = 0

        while not done:
            # --- EXPLORE or EXPLOIT ---
            if rng.random() < epsilon:
                action = env.action_space.sample()          # explore: try anything
            else:
                action = int(np.argmax(Q[state]))           # exploit: best known move

            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated

            # --- THE Q-LEARNING UPDATE ---
            # Build the "target": what this move turned out to be worth.
            # If this step ENDED the episode (goal or hole), there is no
            # next state to look ahead to, so the target is just the reward.
            # Otherwise, target = reward + discounted best value of next state.
            if terminated:
                target = reward
            else:
                best_next = np.max(Q[next_state])   # best we expect next
                target = reward + gamma * best_next  # gamma = discount factor

            # TD (temporal-difference) error = surprise =
            # the target minus what we currently estimated:
            td_error = target - Q[state, action]
            # move our estimate a fraction (alpha) toward the truth:
            Q[state, action] += alpha * td_error

            state = next_state
            total += reward

        rewards_per_episode.append(total)
        # slowly explore less as we grow confident:
        epsilon = max(min_epsilon, epsilon - decay)

    env.close()
    return Q, rewards_per_episode


def show_policy(Q):
    """Print the greedy action the agent would pick on each tile."""
    print("\nLearned policy (best move per tile):")
    for row in range(4):
        line = ""
        for col in range(4):
            s = row * 4 + col
            line += f"{ACTIONS[int(np.argmax(Q[s]))]:>6}"
        print(" ", line)


def main():
    print("=== Training a Q-learning agent on FrozenLake ===")
    Q, history = train()

    # Report how often it won in the last 1000 episodes.
    recent = np.mean(history[-1000:])
    print(f"\nWin rate over last 1000 episodes: {recent:.1%}")
    show_policy(Q)

    # Save the table + learning curve so script 04 can plot it.
    np.save("q_table.npy", Q)
    np.save("q_history.npy", np.array(history))
    print("\nSaved q_table.npy and q_history.npy")


if __name__ == "__main__":
    main()
