"""
03_watch_trained_agent.py
=========================
GOAL: Use the policy learned in script 02 and watch it walk to the goal.

This shows the payoff of learning: the same world where a random agent almost
always failed is now solved almost every time. It also reinforces the idea of a
POLICY - a rule that maps each state to the best action.

Requires: q_table.npy (created by running 02_q_learning.py first).

Run:
    python 03_watch_trained_agent.py
"""

import os
import numpy as np
from shared_env import make_env, ACTIONS


def load_q_table(path="q_table.npy"):
    if not os.path.exists(path):
        raise SystemExit(
            "q_table.npy not found. Run 02_q_learning.py first to create it."
        )
    return np.load(path)


def play_episode(env, Q, show_grid=True):
    """Play greedily (always the best known move) and print the path."""
    state, _ = env.reset(seed=42)
    done = False
    steps = 0
    while not done:
        action = int(np.argmax(Q[state]))     # POLICY: best move for this state
        state, reward, terminated, truncated, _ = env.step(action)
        done = terminated or truncated
        steps += 1
        if show_grid:
            print(env.render())
        else:
            print(f"  step {steps}: {ACTIONS[action]} -> tile {state}, reward {reward}")
    return reward, steps


def main():
    Q = load_q_table()
    env = make_env(render_mode="ansi")   # text picture of the grid each step
    print("=== Trained agent walking to the goal ===\n")
    reward, steps = play_episode(env, Q)
    if reward > 0:
        print(f"\nReached the goal in {steps} steps. The learned policy works!")
    else:
        print("\nDid not reach the goal this run (try re-training longer).")
    env.close()


if __name__ == "__main__":
    main()
