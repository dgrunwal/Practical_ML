"""
01_explore_environment.py
=========================
GOAL: Meet the five essential RL elements in code -- agent, environment,
state, action, reward -- and watch the perceive -> decide -> act loop run.

This script uses a *random* agent (it just picks moves at random). It does not
learn yet; it only shows you the moving parts. Later scripts add real learning.

Run:
    python 01_explore_environment.py
"""

from shared_env import make_env, ACTIONS


def run_one_episode(env, max_steps=20):
    """Play a single episode with a random agent and narrate every step."""
    # reset() gives us the very first STATE (an observation of the world).
    state, info = env.reset(seed=0)
    print(f"Start state: tile {state}")

    total_reward = 0
    for step in range(max_steps):
        # --- PERCEIVE ---  the agent already 'sees' `state`.
        # --- DECIDE  ---  a random agent just samples any legal action.
        action = env.action_space.sample()

        # --- ACT ---  send the action to the environment.
        # The environment returns: new state, reward, and whether we're done.
        next_state, reward, terminated, truncated, info = env.step(action)
        total_reward += reward

        print(f"  step {step:2d}: did {ACTIONS[action]:5s} "
              f"-> tile {next_state:2d}, reward {reward}")

        state = next_state
        if terminated or truncated:
            # terminated = reached goal or fell in a hole.
            print("  (episode ended)")
            break

    print(f"Total reward this episode: {total_reward}\n")
    return total_reward


def main():
    env = make_env()  # shared FrozenLake world
    print("=== Random agent exploring FrozenLake ===\n")
    print(f"This world has {env.observation_space.n} states "
          f"and {env.action_space.n} actions.\n")

    # Run a few episodes so you can see how random behaviour rarely wins.
    wins = 0
    episodes = 5
    for ep in range(episodes):
        print(f"--- Episode {ep + 1} ---")
        if run_one_episode(env) > 0:
            wins += 1

    print(f"Random agent reached the goal in {wins}/{episodes} episodes.")
    print("Notice how seldom random moves succeed -- that is why we need learning.")
    env.close()


if __name__ == "__main__":
    main()
