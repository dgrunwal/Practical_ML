"""
shared_env.py
=============
One place that builds the SAME environment for every script in this project.

Why a shared file?
------------------
Every demo in this folder learns on the *same* little world, so you only have to
understand one environment. That world is **FrozenLake** from Gymnasium (the
maintained successor to OpenAI Gym).

FrozenLake in plain words
-------------------------
Imagine a 4x4 grid of frozen tiles. You start at the top-left (S) and want to
reach a gift at the bottom-right (G). Some tiles are Holes (H) - step on one and
the episode ends with no reward. Safe ice is F (frozen).

    S F F F
    F H F H
    F F F H
    H F F G

- STATES  : 16 tiles, numbered 0..15 (this is the "state" the agent sees).
- ACTIONS : 4 moves -> 0=Left, 1=Down, 2=Right, 3=Up.
- REWARD  : +1 only when the agent reaches G, otherwise 0.

We set is_slippery=False so the ice is NOT slippery. That makes the world
*deterministic* (a given action leads to one predictable next state), which is
the easiest case for a beginner to reason about. Set slippery=True later to see
a *stochastic* world, where the same action can slip to different tiles.

A note on "state" vs "observation": on this small map the number the agent
receives fully identifies which tile it is on, so here observation = state. In
harder problems the observation can be incomplete or noisy, and then it is only
part of the true underlying state.
"""

import gymnasium as gym

# Human-readable names for the four actions, handy when we print things.
ACTIONS = {0: "Left", 1: "Down", 2: "Right", 3: "Up"}


def make_env(render_mode=None, slippery=False):
    """Return a fresh FrozenLake environment.

    render_mode=None      -> no visuals (fast, good for training)
    render_mode="ansi"    -> text picture of the grid
    render_mode="human"   -> pop-up window (needs a display; optional)
    slippery=False        -> deterministic ice (recommended for learning)
    """
    return gym.make(
        "FrozenLake-v1",
        map_name="4x4",
        is_slippery=slippery,
        render_mode=render_mode,
    )


if __name__ == "__main__":
    # Quick self-check: build the env and print its sizes.
    env = make_env()
    print("Number of states  :", env.observation_space.n)
    print("Number of actions :", env.action_space.n)
    print("Action meanings   :", ACTIONS)
    env.close()
