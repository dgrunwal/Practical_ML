"""
04_plot_learning_curve.py
=========================
GOAL: Draw the LEARNING CURVE so you can *see* the agent improving.

The x-axis is training episodes; the y-axis is the average reward (win rate).
A rising curve is the visual signature of reinforcement learning working: early
on the agent mostly fails, then it climbs as the value estimates get better.

Requires: q_history.npy (created by running 02_q_learning.py first).

Run:
    python 04_plot_learning_curve.py
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")          # save to a file instead of opening a window
import matplotlib.pyplot as plt

NAVY = "#1F3864"


def moving_average(x, window=100):
    """Smooth a noisy signal so the trend is easy to see."""
    if len(x) < window:
        return x
    return np.convolve(x, np.ones(window) / window, mode="valid")


def main():
    if not os.path.exists("q_history.npy"):
        raise SystemExit("q_history.npy not found. Run 02_q_learning.py first.")

    history = np.load("q_history.npy")
    smooth = moving_average(history, window=100)

    plt.figure(figsize=(8, 4))
    plt.plot(smooth, color=NAVY, linewidth=2)
    plt.title("Q-learning on FrozenLake: win rate improves with training")
    plt.xlabel("Training episode (smoothed over 100)")
    plt.ylabel("Average reward (win rate)")
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig("learning_curve.png", dpi=150)
    print("Saved learning_curve.png -- open it to see the agent learning.")


if __name__ == "__main__":
    main()
