========================================================================
 REINFORCEMENT LEARNING - BEGINNER SAMPLE PROJECT
 Companion code for "Reinforcement Learning: Essentials (Qwik Guide)"
========================================================================

WHAT'S INSIDE
-------------
  requirements.txt              the Python packages you need
  run_all.py                    runs all four demos in the right order
  README.txt                    this file
  scripts/
    shared_env.py               builds the ONE shared world (FrozenLake)
    01_explore_environment.py   meet agent/env/state/action/reward (random agent)
    02_q_learning.py            train a real value-based, model-free agent
    03_watch_trained_agent.py   watch the trained policy reach the goal
    04_plot_learning_curve.py   plot the agent improving over time

All four scripts use the SAME environment (FrozenLake) on purpose, so you only
have to learn one little world.

------------------------------------------------------------------------
STEP 1 - Open a terminal in this folder
------------------------------------------------------------------------
Change into the folder that contains this README.txt.

------------------------------------------------------------------------
STEP 2 - Create a virtual environment (keeps things tidy)
------------------------------------------------------------------------
A "virtual environment" is a private sandbox for this project's packages.

  Windows (PowerShell):
      python -m venv .venv
      .venv\Scripts\Activate.ps1

  Windows (Command Prompt):
      python -m venv .venv
      .venv\Scripts\activate.bat

  macOS / Linux:
      python3 -m venv .venv
      source .venv/bin/activate

When it is active you'll see (.venv) at the start of your prompt.

------------------------------------------------------------------------
STEP 3 - Install the requirements
------------------------------------------------------------------------
      python -m pip install --upgrade pip
      pip install -r requirements.txt

  (The requirements use gymnasium[toy-text], which includes the FrozenLake
   environment. Plain `pip install gymnasium` may leave it out.)

  Want to go further after these demos?
    * Stable-Baselines3 - ready-made RL algorithm implementations
    * PettingZoo        - multi-agent environments
  Install those only if/when a later project needs them.

------------------------------------------------------------------------
STEP 4 - Run everything at once (easiest)
------------------------------------------------------------------------
      python run_all.py

...OR run them one at a time to study each idea:

      cd scripts
      python 01_explore_environment.py
      python 02_q_learning.py
      python 03_watch_trained_agent.py
      python 04_plot_learning_curve.py

(Run 02 before 03 and 04 - it creates the files they need.)

------------------------------------------------------------------------
STEP 5 - See the result
------------------------------------------------------------------------
Open  scripts/learning_curve.png  to see the win rate climb as the agent
learns. That rising line is reinforcement learning working.

------------------------------------------------------------------------
FILES THE SCRIPTS CREATE (and where)
------------------------------------------------------------------------
Only script 02 and script 04 write files. They are all written into the
scripts/ folder (each script saves using a plain filename, so the files
land in whatever folder the script runs from -- which is scripts/ whether
you use run_all.py or run them there by hand).

  02_q_learning.py  creates:
      scripts/q_table.npy     the learned Q-table (state-action values)
      scripts/q_history.npy   per-episode reward history (for the plot)

  03_watch_trained_agent.py  creates:
      (nothing -- it only READS scripts/q_table.npy and prints to screen)

  04_plot_learning_curve.py  creates:
      scripts/learning_curve.png   the win-rate-over-time graph
                                   (it READS scripts/q_history.npy)

  01_explore_environment.py  creates:
      (nothing -- it only prints to screen)

These are generated outputs, safe to delete anytime; re-running the
scripts recreates them. Run 02 before 03 and 04, since it makes the
.npy files they depend on.

------------------------------------------------------------------------
WHEN YOU'RE DONE
------------------------------------------------------------------------
Leave the sandbox with:
      deactivate

------------------------------------------------------------------------
TROUBLESHOOTING
------------------------------------------------------------------------
* "python not found" -> try python3 instead of python.
* PowerShell blocks activation -> run once:
      Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
* Old "gym" vs "gymnasium": this project uses gymnasium, the maintained
  successor. The import line is  `import gymnasium as gym`.

(c) 2026 David Grunwald. All rights reserved.
