"""
run_all.py
==========
Runs every demo in order, so you can test the whole project with ONE command:

    python run_all.py

Order matters: script 02 trains and saves files that scripts 03 and 04 use.
You can still run each script on its own (see README.txt) if you prefer.
"""

import subprocess
import sys
import os

# Always run from the scripts/ folder so saved .npy files land together.
HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS_DIR = os.path.join(HERE, "scripts")

STEPS = [
    ("Explore the environment (random agent)", "01_explore_environment.py"),
    ("Train the Q-learning agent",             "02_q_learning.py"),
    ("Watch the trained agent play",           "03_watch_trained_agent.py"),
    ("Plot the learning curve",                "04_plot_learning_curve.py"),
]


def main():
    print("=" * 60)
    print("Reinforcement Learning sample project - running all demos")
    print("=" * 60)
    for title, script in STEPS:
        print(f"\n>>> {title}  ({script})\n" + "-" * 60)
        result = subprocess.run([sys.executable, script], cwd=SCRIPTS_DIR)
        if result.returncode != 0:
            print(f"\n{script} exited with an error. Stopping.")
            sys.exit(result.returncode)
    print("\n" + "=" * 60)
    print("All demos finished. See scripts/learning_curve.png for the result.")
    print("=" * 60)


if __name__ == "__main__":
    main()
