"""
common.py  -  Shared helpers used by every script in this package.

WHY THIS FILE EXISTS
--------------------
All of the sample programs use the SAME tiny practice world, called
"FrozenLake". Instead of copying the setup code into every script, we
write it once here and import it. That keeps each lesson short and lets
you focus on the one new idea it teaches.

FrozenLake in one paragraph:
    You stand on a 4x4 grid of frozen tiles. Some tiles are safe ice,
    some are holes you can fall through, one is the goal. You try to
    walk from the start (top-left) to the goal (bottom-right) without
    falling in a hole. Reaching the goal gives a reward of 1. Everything
    else gives 0. That is the whole game.

We turn OFF the "slippery" option so the ice behaves predictably while
you are learning. (With slippery ice the agent sometimes slides sideways,
which is realistic but confusing for a first lesson.)
"""

import gymnasium as gym


# The name of the practice world every script shares.
ENV_ID = "FrozenLake-v1"


def make_env(render_mode=None, slippery=False):
    """Create and return a fresh FrozenLake environment.

    render_mode=None      -> no on-screen drawing (fast, used for training)
    render_mode="ansi"    -> returns a text picture of the grid
    slippery=False         -> predictable ice (good for learning)
    """
    return gym.make(
        ENV_ID,
        is_slippery=slippery,
        render_mode=render_mode,
    )


def describe_env(env):
    """Print the two numbers that define the size of our problem.

    observation_space.n  = how many states (tiles) exist  -> 16
    action_space.n       = how many moves the agent has    -> 4
    Together these are the shape of the Q-table: 16 rows x 4 columns.
    """
    n_states = env.observation_space.n
    n_actions = env.action_space.n
    print(f"[env] states (tiles)      : {n_states}")
    print(f"[env] actions (moves)     : {n_actions}  (0=Left 1=Down 2=Right 3=Up)")
    print(f"[env] Q-table shape will be: {n_states} rows x {n_actions} columns")
    return n_states, n_actions


if __name__ == "__main__":
    # Running this file on its own just prints a quick sanity check.
    print("Quick check of the shared FrozenLake environment:\n")
    env = make_env()
    describe_env(env)
    env.close()
    print("\nGood - the environment loads. You are ready to run the lessons.")
