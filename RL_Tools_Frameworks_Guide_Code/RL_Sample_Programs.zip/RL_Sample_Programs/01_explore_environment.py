"""
LESSON 1  -  Meet the environment
=================================

GOAL OF THIS LESSON
    Before an agent can learn, you need to understand the world it lives
    in. This script pokes at the FrozenLake environment and prints what
    it finds, so the words "state", "action", "reward", and "step"
    stop being abstract.

KEY TERMS YOU WILL SEE IN ACTION
    state   - which tile the agent is standing on (a number 0..15)
    action  - a move the agent chooses (0=Left 1=Down 2=Right 3=Up)
    reward  - the score the world hands back after a move (0 or 1)
    step    - one action + the world's reply (new state, reward, done)
    episode - one full attempt, from start tile until goal or hole

Run it with:   python 01_explore_environment.py
"""

from common import make_env, describe_env


def main():
    # render_mode="ansi" lets us print a little text picture of the grid.
    env = make_env(render_mode="ansi")

    print("=" * 60)
    print("STEP A: How big is this world?")
    print("=" * 60)
    describe_env(env)

    print("\n" + "=" * 60)
    print("STEP B: Reset the world to get our first state")
    print("=" * 60)
    # reset() starts a new episode and returns the first state.
    state, info = env.reset(seed=42)
    print(f"[reset] starting state = {state}  (tile 0 is the top-left corner)")
    print(env.render())  # text picture of the grid

    print("=" * 60)
    print("STEP C: Take a few random moves and watch what comes back")
    print("=" * 60)
    print("Each move prints: chosen action -> (new state, reward, done)\n")

    for move_number in range(1, 6):
        # Pick a random legal action just to see the mechanics.
        action = env.action_space.sample()

        # step() is the heartbeat of RL: give an action, get four things back.
        new_state, reward, terminated, truncated, info = env.step(action)
        done = terminated or truncated

        action_name = {0: "Left", 1: "Down", 2: "Right", 3: "Up"}[action]
        print(f"move {move_number}: action={action} ({action_name:5s}) "
              f"-> new_state={new_state:2d}  reward={reward}  done={done}")

        if done:
            # done becomes True when we reach the goal or fall in a hole.
            outcome = "reached the GOAL!" if reward == 1 else "fell in a hole."
            print(f"        episode ended - the agent {outcome}")
            break

    env.close()

    print("\n" + "=" * 60)
    print("WHAT TO TAKE AWAY")
    print("=" * 60)
    print("- The agent only ever sees a STATE (a tile number).")
    print("- It chooses an ACTION.")
    print("- The world replies with a NEW STATE and a REWARD.")
    print("- Learning (next lessons) is just: choose better actions over time.")


if __name__ == "__main__":
    main()
