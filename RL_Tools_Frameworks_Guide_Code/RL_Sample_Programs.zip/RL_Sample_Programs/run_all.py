"""
run_all.py  -  Run every lesson in order and report pass/fail
=============================================================

This is the "one script to run and test them all" option. It runs each
lesson as a separate program and checks that it finishes without error.

    python run_all.py

Prefer to go one at a time? Just run any single lesson yourself, e.g.:

    python 01_explore_environment.py

Lesson 5 (Keras) is treated as OPTIONAL: if TensorFlow is not installed
it still "passes", because the script is written to explain itself in
words rather than crash.
"""

import subprocess
import sys

# The lessons, in teaching order.
SCRIPTS = [
    "common.py",                      # sanity check of the shared env
    "01_explore_environment.py",
    "02_random_agent.py",
    "03_qlearning_frozenlake.py",
    "04_visualize_learning.py",
    "05_build_dqn_model.py",          # optional deep-learning lesson
]


def run_one(script):
    print("\n" + "#" * 64)
    print(f"# RUNNING: {script}")
    print("#" * 64)
    result = subprocess.run(
        [sys.executable, script],
        capture_output=True,
        text=True,
    )
    # Show the script's own output so you can read what it taught.
    print(result.stdout, end="")
    if result.stderr.strip():
        print("--- messages ---")
        print(result.stderr, end="")
    return result.returncode == 0


def main():
    print("Running all RL lessons. This takes a minute or two.")
    results = {}
    for script in SCRIPTS:
        ok = run_one(script)
        results[script] = ok

    print("\n" + "=" * 64)
    print("SUMMARY")
    print("=" * 64)
    for script, ok in results.items():
        status = "PASS" if ok else "FAIL"
        print(f"  [{status}]  {script}")

    n_pass = sum(1 for ok in results.values() if ok)
    print(f"\n{n_pass} of {len(results)} scripts finished cleanly.")
    if n_pass == len(results):
        print("All good - you have a working RL sandbox. Happy learning!")


if __name__ == "__main__":
    main()
