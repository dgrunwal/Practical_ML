"""
LESSON 2  -  A random agent (the "do nothing smart" baseline)
=============================================================

GOAL OF THIS LESSON
    Measure how often a totally random walker reaches the goal. This
    gives us a BASELINE score. In Lesson 3, Q-learning should beat it.
    Always knowing your baseline is a good habit in machine learning.

KEY TERMS
    baseline - a simple result you compare smarter methods against
    success rate - fraction of episodes that reached the goal

Run it with:   python 02_random_agent.py
"""

from common import make_env


def run_random_agent(episodes=1000):
    env = make_env()
    successes = 0

    for _ in range(episodes):
        state, info = env.reset()
        done = False

        # Keep moving until the episode ends (goal or hole).
        while not done:
            action = env.action_space.sample()   # pure random choice
            state, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated

        # reward == 1 only on the step that reaches the goal.
        if reward == 1:
            successes += 1

    env.close()
    return successes, episodes


def main():
    print("Letting a RANDOM agent try FrozenLake 1000 times...\n")
    successes, episodes = run_random_agent(episodes=1000)
    rate = successes / episodes

    print(f"[result] reached goal in {successes} of {episodes} episodes")
    print(f"[result] success rate    = {rate:.1%}")
    print()
    print("Remember this number. A random agent has no memory and never")
    print("improves. In the next lesson the agent will LEARN, and its")
    print("success rate should climb well above this baseline.")


if __name__ == "__main__":
    main()
