"""
LESSON 3  -  Q-learning from scratch  (THE MAIN EVENT)
======================================================

GOAL OF THIS LESSON
    Teach an agent to solve FrozenLake using a Q-table and the Q-learning
    update rule. This is the algorithm the course transcript walks
    through - here it is, fully commented, on modern libraries.

THE ONE FORMULA (the Q-learning rule)
    Q(s,a) <- Q(s,a) + lr * ( r + gamma * max Q(s',:) - Q(s,a) )

    In plain words: nudge the old score for (state, action) toward
    "reward we just got + how good the best next move looks".

    lr    (learning rate) = how big a nudge            (we use 0.8)
    gamma (discount)      = how much the future matters (we use 0.95)

    NOTE ON THE ORIGINAL TRANSCRIPT: the course used the old OpenAI Gym
    (`gym`, FrozenLake-v0) where env.step() returned 4 values and the
    table was built with np.zeros([...]). We use the maintained
    Gymnasium (`gymnasium`, FrozenLake-v1) where step() returns 5 values.
    The learning math is identical.

EXPLORATION vs EXPLOITATION
    Early on the agent knows nothing, so it should EXPLORE (try random
    moves). Later it should EXPLOIT (trust its Q-table). We balance the
    two with "epsilon-greedy": pick a random move with probability
    epsilon, otherwise pick the best known move. Epsilon starts high and
    decays toward 0.

Run it with:   python 03_qlearning_frozenlake.py
"""

import numpy as np
from common import make_env, describe_env


def train(episodes=5000, lr=0.8, gamma=0.95, seed=0):
    rng = np.random.default_rng(seed)
    env = make_env()

    n_states, n_actions = describe_env(env)

    # THE Q-TABLE: one score per (state, action). Start at all zeros -
    # the agent begins knowing nothing.
    Q = np.zeros((n_states, n_actions))

    # Exploration schedule.
    epsilon = 1.0            # start fully exploring
    min_epsilon = 0.01
    decay = 0.9995           # shrink epsilon a little each episode

    rewards_per_episode = []

    print("\nTraining... (watch the average reward climb)\n")
    for ep in range(1, episodes + 1):
        state, info = env.reset()
        done = False
        total_reward = 0.0

        while not done:
            # --- CHOOSE AN ACTION (epsilon-greedy) ---
            if rng.random() < epsilon:
                action = env.action_space.sample()          # explore
            else:
                action = int(np.argmax(Q[state, :]))        # exploit

            # --- TAKE THE ACTION ---
            new_state, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated

            # --- THE Q-LEARNING UPDATE (the one formula) ---
            best_next = np.max(Q[new_state, :])
            Q[state, action] = Q[state, action] + lr * (
                reward + gamma * best_next - Q[state, action]
            )

            state = new_state
            total_reward += reward

        rewards_per_episode.append(total_reward)

        # Decay exploration.
        epsilon = max(min_epsilon, epsilon * decay)

        # Progress report every 1000 episodes.
        if ep % 1000 == 0:
            window = rewards_per_episode[-1000:]
            avg = sum(window) / len(window)
            print(f"[ep {ep:5d}] avg reward over last 1000 = {avg:.3f}   "
                  f"epsilon now = {epsilon:.3f}")

    env.close()
    return Q, rewards_per_episode


def show_policy(Q):
    """Turn the finished Q-table into a human-readable set of directions."""
    arrows = {0: "<", 1: "v", 2: ">", 3: "^"}   # Left Down Right Up
    print("\nLearned policy (best move on each tile; H=hole G=goal):")
    # FrozenLake default map layout (S start, F frozen, H hole, G goal):
    layout = "SFFFFHFHFFFHHFFG"
    for row in range(4):
        line = []
        for col in range(4):
            i = row * 4 + col
            if layout[i] == "H":
                line.append(" H ")
            elif layout[i] == "G":
                line.append(" G ")
            else:
                line.append(f" {arrows[int(np.argmax(Q[i]))]} ")
        print("   " + "|".join(line))


def evaluate(Q, episodes=1000):
    """Play greedily (no exploration) to measure the learned success rate."""
    env = make_env()
    successes = 0
    for _ in range(episodes):
        state, info = env.reset()
        done = False
        while not done:
            action = int(np.argmax(Q[state, :]))
            state, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated
        if reward == 1:
            successes += 1
    env.close()
    return successes / episodes


def main():
    Q, history = train()

    print("\n" + "=" * 60)
    print("FINISHED TRAINING - here is what the agent learned")
    print("=" * 60)
    np.set_printoptions(precision=3, suppress=True)
    print("\nFinal Q-table (rows = tiles 0..15, columns = Left/Down/Right/Up):")
    print(Q)

    show_policy(Q)

    rate = evaluate(Q)
    print(f"\n[result] greedy success rate after learning = {rate:.1%}")
    print("Compare that to Lesson 2's random baseline - big improvement!")


if __name__ == "__main__":
    main()
