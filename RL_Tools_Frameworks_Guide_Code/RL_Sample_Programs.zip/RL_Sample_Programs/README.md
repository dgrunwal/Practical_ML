# Reinforcement Learning — Sample Programs

Companion code for the training guide **"Reinforcement Learning Tools &
Frameworks — A Beginner's Qwik Guide."**

Everything here uses **one tiny practice world (FrozenLake)** so you can
focus on ideas, not setup. The lessons build on each other:

| Lesson | File | What it teaches |
|-------:|------|-----------------|
| 1 | `01_explore_environment.py` | state, action, reward, step, episode |
| 2 | `02_random_agent.py` | a baseline score to beat |
| 3 | `03_qlearning_frozenlake.py` | **Q-learning and the Q-table (the core)** |
| 4 | `04_visualize_learning.py` | a chart of the agent improving |
| 5 | `05_build_dqn_model.py` | a Keras Deep-Q network (optional) |

`common.py` holds the shared environment setup. `run_all.py` runs and
checks every lesson at once.

---

## Step 1 — Create a virtual environment

A "virtual environment" is a private sandbox for this project's packages,
so they don't collide with anything else on your computer.

**macOS / Linux**
```bash
cd RL_Sample_Programs
python3 -m venv venv
source venv/bin/activate
```

**Windows (PowerShell)**
```powershell
cd RL_Sample_Programs
python -m venv venv
venv\Scripts\Activate.ps1
```

When it is active you'll see `(venv)` at the start of your prompt.

## Step 2 — Install the requirements

```bash
pip install -r requirements.txt
```

This installs Gymnasium, NumPy, and Matplotlib (small, quick). TensorFlow
is optional and left out by default — Lesson 5 runs without it.

## Step 3 — Run the lessons

**All at once (runs and verifies every lesson):**
```bash
python run_all.py
```

**Or one at a time — recommended for reading along:**
```bash
python 01_explore_environment.py
python 02_random_agent.py
python 03_qlearning_frozenlake.py
python 04_visualize_learning.py
python 05_build_dqn_model.py
```

Lesson 4 saves a chart, `learning_curve.png`, in this folder.

## Step 4 — When you're done

```bash
deactivate
```

---

## Want the real Deep Q-network in Lesson 5?

Open `requirements.txt`, remove the `# ` in front of the `tensorflow`
line, and run `pip install -r requirements.txt` again. Then re-run
`python 05_build_dqn_model.py` to see the actual Keras model summary.
Without TensorFlow, Lesson 5 still runs and explains the model in words.

---

## A note on library versions

The original course used the older **OpenAI Gym** (`gym`, `FrozenLake-v0`)
and **keras-rl**, which no longer run on current Python. These scripts use
the maintained replacement, **Gymnasium** (`gymnasium`, `FrozenLake-v1`).
The reinforcement-learning ideas are identical; only a few function names
differ, and the scripts note those differences in comments.

© 2026 David Grunwald. All rights reserved.
