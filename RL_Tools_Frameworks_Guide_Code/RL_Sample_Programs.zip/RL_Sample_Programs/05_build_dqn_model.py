"""
LESSON 5  -  Building the brain for Deep Q-learning (Keras)
===========================================================

GOAL OF THIS LESSON
    When a world has too many states to fit in a table, we replace the
    Q-table with a small NEURAL NETWORK that ESTIMATES Q-values. This
    script builds exactly the kind of network the course transcript
    builds with Keras, and prints its summary.

    We do NOT train it here (training a DQN well needs more moving parts).
    The point of this lesson is to connect the vocabulary - Sequential,
    Dense, Flatten, activation, ReLU, linear - to real code you can read.

    IMPORTANT - what this is and isn't:
    This model is the Q-VALUE APPROXIMATOR at the heart of deep Q-learning.
    A full DQN TRAINING SYSTEM also adds two stabilizers that this lesson
    does not implement:
      1. an experience replay buffer (store past transitions, sample them)
      2. a target network (a slowly-updated copy used for the update target)
    So: this is the network a DQN uses, not the entire DQN algorithm.

WHAT THE LAYERS MEAN
    Sequential : a stack of layers, one after another
    Flatten    : turns the input into a flat list of numbers
    Dense(16)  : a fully-connected layer with 16 neurons
    ReLU       : the activation used on hidden layers
    linear     : the activation on the FINAL layer, because Q-values are
                 plain numbers (not probabilities)

GRACEFUL FALLBACK
    TensorFlow/Keras can be heavy to install. If it is not available this
    script explains the model in words instead of crashing, so the rest
    of the package still runs.

Run it with:   python 05_build_dqn_model.py
"""

# CartPole has a 4-number state and 2 actions - a classic DQN toy problem.
STATE_SIZE = 4
NUM_ACTIONS = 2


def build_with_keras():
    from tensorflow import keras
    from tensorflow.keras import layers

    # This mirrors the transcript: Sequential + Flatten + Dense/ReLU stack,
    # ending in a Dense(num_actions) with a LINEAR activation.
    model = keras.Sequential([
        layers.Input(shape=(1, STATE_SIZE)),
        layers.Flatten(),
        layers.Dense(16, activation="relu"),
        layers.Dense(16, activation="relu"),
        layers.Dense(16, activation="relu"),
        layers.Dense(NUM_ACTIONS, activation="linear"),
    ])
    model.compile(optimizer="adam", loss="mse")
    return model


def explain_in_words():
    print("TensorFlow/Keras is not installed, so here is the model in words:")
    print()
    print("  Input        : a state of 4 numbers")
    print("  Flatten      : flatten to a 1-D list")
    print("  Dense(16)    : 16 neurons, ReLU activation")
    print("  Dense(16)    : 16 neurons, ReLU activation")
    print("  Dense(16)    : 16 neurons, ReLU activation")
    print(f"  Dense({NUM_ACTIONS})     : one output per action, LINEAR activation")
    print()
    print("  The final layer has LINEAR activation because each output is")
    print("  a Q-value (an unbounded score), not a probability.")
    print()
    print("  To try the real thing later:  pip install tensorflow")


def main():
    print("=" * 60)
    print("Building a Deep Q-Network with Keras")
    print("=" * 60)
    try:
        model = build_with_keras()
        print("Keras model built. Here is its summary:\n")
        model.summary()
        print("\nEach 'Dense' row is a layer. 'Param #' counts the numbers")
        print("the network will tune during training (its weights & biases).")
    except Exception as e:
        print(f"(Keras unavailable: {e})\n")
        explain_in_words()


if __name__ == "__main__":
    main()
