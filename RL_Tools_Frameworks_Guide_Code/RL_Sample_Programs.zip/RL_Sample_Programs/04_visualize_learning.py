"""
LESSON 4  -  See the learning happen (a picture of progress)
============================================================

GOAL OF THIS LESSON
    Numbers scrolling past are hard to feel. This script trains the same
    Q-learning agent from Lesson 3, then draws a chart of how its success
    rate climbs over time. Watching the curve rise is the "aha" moment.

WHAT IT SAVES
    learning_curve.png  - a chart in this folder you can open.

Run it with:   python 04_visualize_learning.py
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")            # save to file instead of opening a window
import matplotlib.pyplot as plt

from common import make_env


def train_tracking(episodes=5000, lr=0.8, gamma=0.95, seed=0):
    """Same Q-learning as Lesson 3, but we record a moving success rate."""
    rng = np.random.default_rng(seed)
    env = make_env()
    n_states = env.observation_space.n
    n_actions = env.action_space.n
    Q = np.zeros((n_states, n_actions))

    epsilon, min_epsilon, decay = 1.0, 0.01, 0.9995
    rewards = []

    for ep in range(episodes):
        state, info = env.reset()
        done = False
        total = 0.0
        while not done:
            if rng.random() < epsilon:
                action = env.action_space.sample()
            else:
                action = int(np.argmax(Q[state, :]))
            new_state, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated
            Q[state, action] += lr * (
                reward + gamma * np.max(Q[new_state, :]) - Q[state, action]
            )
            state = new_state
            total += reward
        rewards.append(total)
        epsilon = max(min_epsilon, epsilon * decay)

    env.close()
    return np.array(rewards)


def moving_average(x, window=100):
    """Smooth the noisy 0/1 outcomes into a readable success-rate curve."""
    return np.convolve(x, np.ones(window) / window, mode="valid")


def main():
    print("Training and recording progress (about 5000 episodes)...")
    rewards = train_tracking()

    curve = moving_average(rewards, window=100)

    plt.figure(figsize=(8, 4.5))
    plt.plot(curve, color="#1F3864", linewidth=2)
    plt.title("FrozenLake: success rate rises as the agent learns",
              color="#1F3864", fontsize=13, fontweight="bold")
    plt.xlabel("episode")
    plt.ylabel("success rate (100-episode average)")
    plt.ylim(-0.02, 1.02)
    plt.grid(True, color="#DDD8CC")
    plt.tight_layout()
    out = "learning_curve.png"
    plt.savefig(out, dpi=130)
    print(f"[saved] {out} - open it to see the learning curve.")
    print(f"[info ] final 100-episode success rate = {curve[-1]:.1%}")


if __name__ == "__main__":
    main()
