#!/usr/bin/env python3
"""
run_all.py — run every example script in order and report pass/fail.
Handy for verifying the whole package after install.

    cd scripts && python ../run_all.py     (or)     python run_all.py from root
"""
import subprocess
import sys
from pathlib import Path

scripts_dir = Path(__file__).resolve().parent / "scripts"
scripts = sorted(p for p in scripts_dir.glob("[0-9]*.py"))

failures = 0
for s in scripts:
    print(f"\n{'='*70}\nRUNNING {s.name}\n{'='*70}")
    r = subprocess.run([sys.executable, s.name], cwd=scripts_dir)
    if r.returncode != 0:
        failures += 1
        print(f"!! {s.name} exited with code {r.returncode}")

print(f"\n{'='*70}")
print(f"Done: {len(scripts) - failures}/{len(scripts)} scripts passed.")
sys.exit(1 if failures else 0)
