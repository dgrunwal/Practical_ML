"""
03_f_statistic_regression.py
Guide section 3.2 — The F-statistic (f_regression)

f_regression scores each numeric feature by its LINEAR association with a
continuous target. Higher F-score (and smaller p-value) = stronger linear link.
Pairs with SelectKBest to keep the k highest-scoring features.

(For classification the sibling is f_classif, an ANOVA F-test that measures how
much a feature's mean differs across classes — see 05_chi2_classification.py's
companion note.)
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import SelectKBest, f_regression

from common import load_house_price


def main():
    X, y = load_house_price()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=0)

    # 1) score every feature (k='all') to inspect the ranking
    scorer = SelectKBest(score_func=f_regression, k="all")
    scorer.fit(X_train, y_train)

    ranking = pd.DataFrame({
        "Feature": X_train.columns,
        "F_score": scorer.scores_,
        "p_value": scorer.pvalues_,
    }).sort_values("F_score", ascending=False).reset_index(drop=True)

    print("F-regression ranking (higher F = stronger linear link to price):\n")
    print(ranking.to_string(index=False))

    # 2) actually select the top k
    k = 8
    selector = SelectKBest(score_func=f_regression, k=k)
    selector.fit(X_train, y_train)
    selected = X_train.columns[selector.get_support()]

    print(f"\nTop {k} features selected:")
    print(list(selected))


if __name__ == "__main__":
    main()
