"""
04_mutual_information.py
Guide section 3.3 — Mutual information (catches non-linear links)

Mutual information (MI) measures how much knowing a feature reduces uncertainty
about the target. Unlike the F-test it detects NON-LINEAR dependence, which is
its main advantage.

Part A reproduces the guide's linear-vs-U-shape illustration on synthetic data,
showing the F-test miss the U-shape while MI catches it.
Part B runs mutual_info_regression on the real house-price data.

Cautions: MI estimates get noisy with limited data, and because it's univariate
it can miss a feature that only matters jointly with others. A near-zero score
in a finite sample is not proof of independence.
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import (SelectKBest, f_regression,
                                       mutual_info_regression)

from common import load_house_price


def part_a_linear_vs_nonlinear():
    print("=" * 60)
    print("Part A — why MI beats the F-test on non-linear relationships")
    print("=" * 60)
    rng = np.random.default_rng(0)
    x = rng.uniform(-3, 3, size=(1000, 1))
    # feature 0 relates to y through a U-shape (quadratic)
    y = (x[:, 0] ** 2) + 0.1 * rng.standard_normal(1000)

    f_scores, _ = f_regression(x, y)
    mi = mutual_info_regression(x, y, random_state=0)

    print(f"\nU-shaped feature vs target:")
    print(f"  F-test score : {f_scores[0]:8.3f}   (near 0 -> F-test misses it)")
    print(f"  MI score     : {mi[0]:8.3f}   (clearly positive -> MI catches it)")


def part_b_real_data():
    print("\n" + "=" * 60)
    print("Part B — mutual_info_regression on the house-price data")
    print("=" * 60)
    X, y = load_house_price()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=0)

    scorer = SelectKBest(
        score_func=lambda Xa, ya: mutual_info_regression(Xa, ya, random_state=0),
        k="all")
    scorer.fit(X_train, y_train)

    ranking = pd.DataFrame({
        "Feature": X_train.columns,
        "MI_score": scorer.scores_,
    }).sort_values("MI_score", ascending=False).reset_index(drop=True)

    print("\nMutual-information ranking:\n")
    print(ranking.to_string(index=False))

    k = 8
    top = ranking.head(k)["Feature"].tolist()
    print(f"\nTop {k} features by MI: {top}")


def main():
    part_a_linear_vs_nonlinear()
    part_b_real_data()


if __name__ == "__main__":
    main()
