"""
09_pca_dimensionality.py
Guide section 6 — Dimensionality reduction with PCA

PCA builds new orthogonal axes (principal components) along the directions of
greatest variance, then keeps just the first few. Choose how many by the
cumulative explained-variance curve (look for the elbow, or a 90/95% threshold).

Two cautions baked into this script:
  * Standardize first when features have different units/scales, so a large-unit
    feature doesn't dominate.
  * Explained variance is INPUT variance, not predictive information. PCA ignores
    the target and can discard a low-variance-but-predictive direction — so we
    also print how many components reach 90% as a starting point only.
"""
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.pipeline import make_pipeline

from common import load_house_price


def main():
    X, y = load_house_price()

    # standardize, then fit full PCA to inspect the variance curve
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    pca_full = PCA().fit(X_scaled)

    cum = np.cumsum(pca_full.explained_variance_ratio_)
    print("Cumulative explained variance by component:\n")
    for i, c in enumerate(cum, start=1):
        print(f"  {i:2d} components: {c:6.1%}")

    n_90 = int(np.argmax(cum >= 0.90) + 1)
    n_95 = int(np.argmax(cum >= 0.95) + 1)
    print(f"\nComponents to reach 90% variance: {n_90}")
    print(f"Components to reach 95% variance: {n_95}")

    # a ready-to-use reducer: keep enough components for 90% variance
    reducer = make_pipeline(StandardScaler(), PCA(n_components=0.90))
    X_reduced = reducer.fit_transform(X)
    print(f"\nReduced data shape: {X.shape} -> {X_reduced.shape}")
    print("Reminder: confirm with cross-validation that the reduced "
          "representation preserves task performance.")


if __name__ == "__main__":
    main()
