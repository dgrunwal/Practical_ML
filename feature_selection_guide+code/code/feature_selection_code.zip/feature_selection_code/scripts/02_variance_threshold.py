"""
02_variance_threshold.py
Guide section 3.1 — Variance threshold (filter method)

Drops features whose variance falls below a cutoff: a near-constant column
carries almost no information.

Important:
  * Variance threshold is UNIT-SENSITIVE. Apply it BEFORE standardization,
    because standardizing forces every feature to variance 1 and would erase
    the differences you're trying to measure.
  * Fit the selector on the TRAINING split only (it's a fitted step, so it can
    leak), then apply the same transform to the test split.
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import VarianceThreshold

from common import load_house_price


def main():
    X, y = load_house_price()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=0)

    selector = VarianceThreshold(threshold=0.05)
    selector.fit(X_train)                      # learn variances on train only
    X_train_sel = selector.transform(X_train)
    X_test_sel = selector.transform(X_test)

    kept = X_train.columns[selector.get_support()]
    dropped = X_train.columns[~selector.get_support()]

    print(f"Original feature count : {X_train.shape[1]}")
    print(f"Kept after threshold   : {X_train_sel.shape[1]}")
    print(f"\nKept features   : {list(kept)}")
    print(f"Dropped features: {list(dropped) if len(dropped) else 'none'}")

    # variances for reference (sorted ascending so low-variance shows first)
    variances = X_train.var().sort_values()
    print("\nLowest-variance features (train):")
    print(variances.head(6).to_string())


if __name__ == "__main__":
    main()
