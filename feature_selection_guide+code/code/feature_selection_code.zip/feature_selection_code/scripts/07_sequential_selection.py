"""
07_sequential_selection.py
Guide section 5.1 — Sequential Feature Selection (SFS)

A wrapper method: it repeatedly trains the model on candidate subsets and keeps
whatever performs best under cross-validation.
  forward  : start empty, add the feature that most improves CV score
  backward : start with all, remove the least useful

Set `scoring` to match your task — the default is estimator-dependent (R^2 for
regressors, accuracy for classifiers). Plain LinearRegression doesn't need
scaling for its ranking; scaling matters for L1/L2 penalties, not here.
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.feature_selection import SequentialFeatureSelector

from common import load_house_price


def run(direction, X_train, y_train, feature_names, n=8):
    sfs = SequentialFeatureSelector(
        LinearRegression(),
        n_features_to_select=n,
        direction=direction,
        scoring="neg_root_mean_squared_error",
        cv=5,
    ).fit(X_train, y_train)
    return feature_names[sfs.get_support()].tolist()


def main():
    X, y = load_house_price()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=0)
    feature_names = X_train.columns

    print("Sequential Feature Selection (n_features_to_select=8)\n")
    fwd = run("forward", X_train, y_train, feature_names)
    print("Forward-selected :", fwd)

    bwd = run("backward", X_train, y_train, feature_names)
    print("Backward-selected:", bwd)

    print("\nIn common:", sorted(set(fwd) & set(bwd)))


if __name__ == "__main__":
    main()
