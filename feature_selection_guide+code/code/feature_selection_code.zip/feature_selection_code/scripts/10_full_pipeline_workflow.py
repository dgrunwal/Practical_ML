"""
10_full_pipeline_workflow.py
Guide section 7 — Putting it together: a safe workflow

A complete, leak-free example that chains preprocessing, feature selection, and
a model into ONE Pipeline, then evaluates it with cross-validation. Because
every fitted step lives inside the pipeline, scaling and selection are learned
on each training fold only — never on the validation fold.

Workflow demonstrated:
  1. Baseline: all features, cross-validated.
  2. Quick filter (SelectKBest) + model, cross-validated.
  3. Compare — did the smaller feature set hold up?

This mirrors the guide's golden rule: fit every learned step on training data
only, inside cross-validation.
"""
import numpy as np
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.feature_selection import SelectKBest, f_regression

from common import load_house_price


def main():
    X, y = load_house_price()

    # 1) baseline: all features
    baseline = make_pipeline(StandardScaler(), LinearRegression())
    base_scores = cross_val_score(
        baseline, X, y, cv=5, scoring="neg_root_mean_squared_error")
    base_rmse = -base_scores.mean()

    # 2) filter to top-k features INSIDE the pipeline (no leakage)
    selected = make_pipeline(
        StandardScaler(),
        SelectKBest(score_func=f_regression, k=8),
        LinearRegression(),
    )
    sel_scores = cross_val_score(
        selected, X, y, cv=5, scoring="neg_root_mean_squared_error")
    sel_rmse = -sel_scores.mean()

    print("5-fold cross-validated RMSE (lower is better):\n")
    print(f"  All {X.shape[1]} features : {base_rmse:,.0f}")
    print(f"  Top 8 features    : {sel_rmse:,.0f}")

    delta = sel_rmse - base_rmse
    verdict = ("smaller set holds up well"
               if delta <= 0.02 * base_rmse else
               "full set predicts better here")
    print(f"\nDifference: {delta:,.0f}  ->  {verdict}")
    print("\nBecause selection happens inside the CV pipeline, these scores are "
          "honest estimates of out-of-sample performance.")


if __name__ == "__main__":
    main()
