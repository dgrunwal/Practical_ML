"""
common.py — shared data loading for the Feature Selection & Dimensionality
Reduction guide scripts.

All scripts import from here so the dataset paths resolve no matter where you
run them from. Datasets live in ../datasets relative to this file.

Datasets
--------
house_price.csv       : 21,613 homes, all-numeric  -> regression examples
bike_buyers_clean.csv : 1,000 customers, mixed types -> classification examples
"""
from pathlib import Path
import pandas as pd

# datasets folder sits next to the scripts folder
DATA_DIR = Path(__file__).resolve().parent.parent / "datasets"


def load_house_price():
    """Return (X, y) for regression. Target = price, all features numeric."""
    df = pd.read_csv(DATA_DIR / "house_price.csv")
    df = df.dropna()
    y = df["price"]
    X = df.drop(columns=["price"])
    return X, y


def load_bike_buyers():
    """
    Return the raw bike-buyers frame for classification.

    Target = 'Purchased Bike' (Yes/No). Mixed numeric + categorical columns;
    each script encodes them as it needs.
    """
    df = pd.read_csv(DATA_DIR / "bike_buyers_clean.csv")
    df = df.dropna()
    # ID is an identifier, not a feature
    if "ID" in df.columns:
        df = df.drop(columns=["ID"])
    return df


if __name__ == "__main__":
    X, y = load_house_price()
    print("house_price :", X.shape, "features; target 'price'")
    bike = load_bike_buyers()
    print("bike_buyers :", bike.shape, "-> target 'Purchased Bike'")
