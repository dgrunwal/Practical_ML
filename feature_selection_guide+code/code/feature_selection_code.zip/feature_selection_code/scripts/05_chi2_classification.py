"""
05_chi2_classification.py
Guide section 3.4 — Chi-squared (for classification)

The chi-squared (chi2) test checks whether a NON-NEGATIVE feature and the class
target are independent. A large chi2 score and small p-value mean they're
related, so the feature is worth keeping.

chi2 requires non-negative inputs (counts, frequencies, or encoded categories).
Here we ordinal-encode the bike-buyers categorical columns to non-negative
integers, then score them against the 'Purchased Bike' target.

Also shows f_classif (ANOVA F-test) on the numeric columns for contrast: it
measures how much each feature's mean differs across the two classes.
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder, LabelEncoder
from sklearn.feature_selection import (SelectPercentile, SelectKBest,
                                       chi2, f_classif)

from common import load_bike_buyers


def main():
    df = load_bike_buyers()
    target = "Purchased Bike"

    y = LabelEncoder().fit_transform(df[target])
    X = df.drop(columns=[target])

    # object/str columns are categorical; the rest are numeric
    cat_cols = X.select_dtypes(include=["object", "string"]).columns.tolist()
    num_cols = [c for c in X.columns if c not in cat_cols]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=0, stratify=y)

    # ---- chi-squared on categorical features (ordinal-encoded, non-negative)
    enc = OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)
    X_train_cat = pd.DataFrame(
        enc.fit_transform(X_train[cat_cols]), columns=cat_cols)
    # ordinal encoding starts at 0, so values are already non-negative on train
    chi_scores, chi_p = chi2(X_train_cat, y_train)
    chi_df = pd.DataFrame({
        "Feature": cat_cols, "Chi2_score": chi_scores, "p_value": chi_p.round(4),
    }).sort_values("Chi2_score", ascending=False).reset_index(drop=True)

    print("Chi-squared scores for categorical features:\n")
    print(chi_df.to_string(index=False))

    selector = SelectPercentile(score_func=chi2, percentile=50)
    selector.fit(X_train_cat, y_train)
    kept = X_train_cat.columns[selector.get_support()]
    print(f"\nTop 50% categorical features by chi2: {list(kept)}")

    # ---- f_classif (ANOVA) on the numeric features, for contrast
    print("\n" + "-" * 60)
    f_scores, f_p = f_classif(X_train[num_cols], y_train)
    f_df = pd.DataFrame({
        "Feature": num_cols, "F_score": f_scores, "p_value": f_p.round(4),
    }).sort_values("F_score", ascending=False).reset_index(drop=True)
    print("f_classif (ANOVA) scores for numeric features:\n")
    print(f_df.to_string(index=False))


if __name__ == "__main__":
    main()
