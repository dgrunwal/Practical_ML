"""
06_embedded_ridge_lasso.py
Guide section 4 — Embedded methods (selection during training)

L2 / Ridge  : shrinks coefficients toward zero (rarely to zero); great for
              correlated predictors. Doesn't drop features on its own, so we do
              a model-based POST-HOC selection with SelectFromModel.
L1 / Lasso  : can push coefficients exactly to zero -> automatic selection.

Key practice: L1/L2 penalties act on coefficient SIZE, so features must be on a
common scale. We wrap StandardScaler + model in a Pipeline so scaling is fit on
each training fold only (no leakage). If you also tune the SelectFromModel
threshold, do it in an outer CV loop (nested CV) so the reported score isn't
optimistic.
"""
import warnings
import numpy as np
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore", category=ConvergenceWarning)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import RidgeCV, LassoCV
from sklearn.feature_selection import SelectFromModel

from common import load_house_price


def ridge_selection(X_train, y_train, feature_names):
    print("=" * 60)
    print("Ridge (L2) + SelectFromModel — model-based post-hoc selection")
    print("=" * 60)

    # scaler + RidgeCV in one pipeline: scaling fits on training folds only
    ridge = make_pipeline(
        StandardScaler(),
        RidgeCV(alphas=np.logspace(-6, 6, num=13)),
    ).fit(X_train, y_train)

    rcv = ridge.named_steps["ridgecv"]
    print(f"RidgeCV chose alpha = {rcv.alpha_:.4g}")

    # keep the strongest features by coefficient magnitude (already fit -> prefit)
    sfm = SelectFromModel(rcv, threshold="median", prefit=True)
    selected = feature_names[sfm.get_support()]
    print(f"Ridge-selected features (|coef| >= median): {list(selected)}")


def lasso_selection(X_train, y_train, feature_names):
    print("\n" + "=" * 60)
    print("Lasso (L1) — automatic selection by zeroing coefficients")
    print("=" * 60)

    lasso = make_pipeline(
        StandardScaler(),
        LassoCV(cv=5, max_iter=10000, random_state=0),
    ).fit(X_train, y_train)

    lcv = lasso.named_steps["lassocv"]
    kept_mask = lcv.coef_ != 0
    kept = feature_names[kept_mask]
    print(f"LassoCV chose alpha = {lcv.alpha_:.4g}")
    print(f"Features kept (non-zero coef): {kept_mask.sum()} of {len(feature_names)}")
    print(f"Kept: {list(kept)}")


def main():
    X, y = load_house_price()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=0)
    feature_names = X_train.columns

    ridge_selection(X_train, y_train, feature_names)
    lasso_selection(X_train, y_train, feature_names)


if __name__ == "__main__":
    main()
