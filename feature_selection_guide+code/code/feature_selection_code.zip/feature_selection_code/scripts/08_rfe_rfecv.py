"""
08_rfe_rfecv.py
Guide section 5.2 — Recursive Feature Elimination (RFE / RFECV)

RFE starts with all features, ranks them by the estimator's importance
(coef_ or feature_importances_), drops the weakest, and REFITS — repeating
until the target count remains. Refitting each round matters: removing a feature
can shift the importance of the survivors.

Whether RFE captures non-linearities/interactions depends entirely on the
estimator you give it. X must already be numeric and preprocessed.

Plain RFE doesn't validate HOW MANY features to keep, so RFECV (shown second)
is the safer default: cross-validation picks the count. We put the scaler and
RFECV in a Pipeline to avoid leakage; the RFECV estimator (LogisticRegression)
exposes coef_, as RFE requires.
"""
import warnings
import numpy as np
from sklearn.exceptions import ConvergenceWarning
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore", category=ConvergenceWarning)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import RFE, RFECV

from common import load_bike_buyers


def prep_bike():
    """Numeric-only view of bike buyers for a clean RFE demo."""
    df = load_bike_buyers()
    target = "Purchased Bike"
    y = LabelEncoder().fit_transform(df[target])
    feats = df.drop(columns=[target])
    num_cols = [c for c in feats.columns
                if c not in feats.select_dtypes(include=["object", "string"]).columns]
    return feats[num_cols], y


def plain_rfe(X_train, y_train, feature_names):
    print("=" * 60)
    print("Plain RFE — fixed number of features")
    print("=" * 60)
    estimator = LogisticRegression(max_iter=1000)
    rfe = RFE(estimator, n_features_to_select=3)
    # scale first (LogisticRegression is regularized); fit on train only
    scaler = StandardScaler().fit(X_train)
    rfe.fit(scaler.transform(X_train), y_train)

    print("support_ (kept?):", dict(zip(feature_names, rfe.support_)))
    print("ranking_ (1=kept):", dict(zip(feature_names, rfe.ranking_)))
    print("Selected:", list(feature_names[rfe.support_]))


def rfecv_pipeline(X, y, feature_names):
    print("\n" + "=" * 60)
    print("RFECV — cross-validation chooses the feature count")
    print("=" * 60)
    model = make_pipeline(
        StandardScaler(),
        RFECV(LogisticRegression(max_iter=1000), scoring="roc_auc", cv=5),
    ).fit(X, y)

    rfecv = model.named_steps["rfecv"]
    print(f"Optimal number of features: {rfecv.n_features_}")
    print("Selected:", list(feature_names[rfecv.support_]))


def main():
    X, y = prep_bike()
    feature_names = X.columns
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=0, stratify=y)

    plain_rfe(X_train, y_train, feature_names)
    rfecv_pipeline(X, y, feature_names)


if __name__ == "__main__":
    main()
