"""
01_multicollinearity_vif.py
Guide section 2 — First, check for multicollinearity

Computes the Variance Inflation Factor (VIF) for each numeric feature.
VIF regresses each feature on all the others; a high value means the feature
is largely explained by the rest, so its coefficient estimate is imprecise.

Rule-of-thumb thresholds (not hard rules):
    ~1        independent of the others
    5 to 10   moderate overlap, worth a look
    > 10      strong overlap; consider dropping/combining or use Ridge

Note: VIF is mainly a diagnostic for INTERPRETING linear-model coefficients.
A high VIF does not necessarily hurt out-of-sample prediction, especially for
regularized or tree-based models.
"""
import warnings
import pandas as pd
from statsmodels.stats.outliers_influence import variance_inflation_factor

from common import load_house_price

# A perfectly-collinear feature makes VIF divide by zero and return inf.
# That's the correct signal (see note in main), so we silence the warning.
warnings.filterwarnings("ignore", message="divide by zero encountered")


def compute_vif(X: pd.DataFrame) -> pd.DataFrame:
    vif = pd.DataFrame({
        "feature": X.columns,
        "VIF": [variance_inflation_factor(X.values, i)
                for i in range(X.shape[1])],
    })
    return vif.sort_values("VIF", ascending=False).reset_index(drop=True)


def main():
    X, _ = load_house_price()

    # VIF is defined for numeric predictors; house_price is already all-numeric.
    vif = compute_vif(X)

    pd.set_option("display.max_rows", None)
    print("Variance Inflation Factor per feature (high = redundant):\n")
    print(vif.to_string(index=False))

    flagged = vif[vif["VIF"] > 10]["feature"].tolist()
    print("\nFeatures with VIF > 10 (strong overlap):",
          flagged if flagged else "none")

    # In this dataset sqft_living = sqft_above + sqft_basement, so those three
    # are PERFECTLY collinear and their VIF is infinite — the model literally
    # cannot split the weight uniquely between them. Dropping one resolves it.
    infinite = vif[vif["VIF"] == float("inf")]["feature"].tolist()
    if infinite:
        print("Perfect multicollinearity (infinite VIF):", infinite)
        print("  -> e.g. sqft_living = sqft_above + sqft_basement; drop one.")


if __name__ == "__main__":
    main()
