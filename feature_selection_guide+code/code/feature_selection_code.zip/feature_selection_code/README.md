# Feature Selection & Dimensionality Reduction — Code Examples

Complete, runnable Python scripts for every code example in the guide
*Feature Selection & Dimensionality Reduction — A Beginner's Field Guide*
(part of the AI Foundations Series).

Each script is self-contained, runs end-to-end on the included datasets, and
prints its results so you can compare against the guide.

## Setup

```bash
# from inside this folder
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Running

Every script is run the same way, from inside the `scripts/` folder:

```bash
cd scripts
python 01_multicollinearity_vif.py
```

Run them in order for the full tour, or pick the one matching the guide section
you're reading.

## What's here

| Script | Guide section | Demonstrates |
|--------|---------------|--------------|
| `common.py`                      | —   | Shared dataset loaders (imported by the others) |
| `01_multicollinearity_vif.py`    | 2   | Variance Inflation Factor; spotting redundant features |
| `02_variance_threshold.py`       | 3.1 | Dropping near-constant features (filter) |
| `03_f_statistic_regression.py`   | 3.2 | `f_regression` + `SelectKBest` (linear association) |
| `04_mutual_information.py`        | 3.3 | Mutual information; the non-linear case the F-test misses |
| `05_chi2_classification.py`      | 3.4 | `chi2` on categorical features; `f_classif` for contrast |
| `06_embedded_ridge_lasso.py`     | 4   | Ridge + `SelectFromModel`; Lasso auto-selection (pipelines) |
| `07_sequential_selection.py`     | 5.1 | Forward & backward `SequentialFeatureSelector` |
| `08_rfe_rfecv.py`                | 5.2 | `RFE` and the safer `RFECV` (in a scaling pipeline) |
| `09_pca_dimensionality.py`       | 6   | PCA explained-variance curve; 90%/95% component counts |
| `10_full_pipeline_workflow.py`   | 7   | End-to-end leak-free pipeline + cross-validation |

## Datasets (in `datasets/`)

- **house_price.csv** — 21,613 homes, all-numeric features. Used for the
  regression examples. Target: `price`.
- **bike_buyers_clean.csv** — 1,000 customers, mixed numeric/categorical.
  Used for the classification examples. Target: `Purchased Bike`.

## Notes for students

- **No data leakage.** Scripts that scale or select fit those steps on the
  training split (or inside a cross-validation pipeline) only — never on test
  data. Scripts 06, 08, and 10 show the pipeline pattern explicitly.
- **Reproducibility.** Random splits use `random_state=0`, so your numbers
  should match on re-runs. Mutual-information and CV results can vary slightly
  across scikit-learn versions.
- **Perfect multicollinearity is real here.** In `house_price.csv`,
  `sqft_living = sqft_above + sqft_basement`, so script 01 reports an *infinite*
  VIF for those columns — exactly the concept from guide section 2.
- **Explained variance ≠ predictive information.** Script 09 prints the PCA
  variance curve but reminds you to confirm downstream performance with
  cross-validation, since PCA ignores the target.

---
© 2026 David Grunwald. All rights reserved.
